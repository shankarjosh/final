package com.ccst.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features="src/test/resources/features",
        glue={"com.ccst.steps","com.ccst.hooks"},
        plugin = {"pretty",
        "html:target/cucumber-report.html"},
        tags="@regression",
        dryRun = false)
public class RunCucumberTest extends AbstractTestNGCucumberTests {
}
