package com.ccst.steps;

import com.ccst.framework.DriverManager;
import com.ccst.pages.LoginPage;
import com.ccst.pages.PaymentPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class PaymentSteps {
    private final WebDriver driver = DriverManager.getDriver();
    private final WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    private LoginPage loginPage;
    private PaymentPage paymentPage;

    @Given("the user is logged in and has added product {string} to the cart")
    public void the_user_is_logged_in_and_has_added_product_to_the_cart(String productName) {
        loginPage = new LoginPage(driver);
        loginPage.open();
        loginPage.login("forccstlabexam@gmail.com", "null7890");
        driver.get("https://automationexercise.com/");
        addProductToCart(productName);
        driver.get("https://automationexercise.com/view_cart");
    }

    @And("the user is on the payment page")
    public void the_user_is_on_the_payment_page() {
        paymentPage = new PaymentPage(driver);
        paymentPage.open();
    }

    @When("the user enters payment details with name {string}, card number {string}, cvc {string}, expiry month {string} and expiry year {string}")
    public void the_user_enters_payment_details_with_name_card_number_cvc_expiry_month_and_expiry_year(
            String name, String cardNumber, String cvcValue, String expiryMonth, String expiryYear) {
        paymentPage.fillCardDetails(name, cardNumber, cvcValue, expiryMonth, expiryYear);
    }

    @And("the user clicks Pay and Confirm Order")
    public void the_user_clicks_pay_and_confirm_order() {
        paymentPage.payAndConfirmOrder();
    }

    @Then("the order is placed successfully")
    public void the_order_is_placed_successfully() {
        Assert.assertTrue(paymentPage.isOrderPlacedSuccessfully());
    }

    @Given("the user has added product {string} to the cart")
    public void the_user_has_added_product_to_the_cart(String productName) {
        driver.get("https://automationexercise.com/");
        addProductToCart(productName);
        driver.get("https://automationexercise.com/view_cart");
    }

    @When("the user proceeds to checkout")
    public void the_user_proceeds_to_checkout() {
        driver.get("https://automationexercise.com/checkout");
    }

    @Then("the checkout page is displayed")
    public void the_checkout_page_is_displayed() {
        Assert.assertTrue(driver.getCurrentUrl().contains("/checkout"));
    }

    private void addProductToCart(String productName) {
        By addToCartButton = By.xpath("//p[normalize-space()='" + productName + "']/ancestor::div[contains(@class,'product-image-wrapper')]//a[contains(@class,'add-to-cart')][1]");
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
        button.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#cartModal")));
        By viewCartLink = By.cssSelector("#cartModal a[href='/view_cart']");
        wait.until(ExpectedConditions.elementToBeClickable(viewCartLink)).click();
    }
}
