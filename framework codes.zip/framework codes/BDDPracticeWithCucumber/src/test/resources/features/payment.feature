Feature: Payment

  @regression
  Scenario: User can access checkout after adding a product
    Given the user is logged in and has added product "Blue Top" to the cart
    When the user proceeds to checkout
    Then the checkout page is displayed

  @regression
  Scenario: User can pay for an order successfully
    Given the user is logged in and has added product "Blue Top" to the cart
    And the user is on the payment page
    When the user enters payment details with name "John Smith", card number "4111111111111111", cvc "123", expiry month "12" and expiry year "2030"
    And the user clicks Pay and Confirm Order
    Then the order is placed successfully
