package com.ccst.pages;

import com.ccst.base.BasePage;
import com.ccst.framework.Config;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PaymentPage extends BasePage {
    private final By nameOnCard = By.cssSelector("[data-qa='name-on-card']");
    private final By cardNumber = By.cssSelector("[data-qa='card-number']");
    private final By cvc = By.cssSelector("[data-qa='cvc']");
    private final By expiryMonth = By.cssSelector("[data-qa='expiry-month']");
    private final By expiryYear = By.cssSelector("[data-qa='expiry-year']");
    private final By payButton = By.cssSelector("[data-qa='pay-button']");
    private final By successAlert = By.cssSelector("#success_message .alert");

    public PaymentPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public String url() {
        return Config.get("baseUrl") + "/payment";
    }

    @Override
    public boolean isLoaded() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(payButton)).isDisplayed();
    }

    public void open() {
        driver.get(url());
    }

    public void fillCardDetails(String name, String cardNo, String cvcValue, String month, String year) {
        enterText(nameOnCard, name);
        enterText(cardNumber, cardNo);
        enterText(cvc, cvcValue);
        enterText(expiryMonth, month);
        enterText(expiryYear, year);
    }

    public void payAndConfirmOrder() {
        click(payButton);
    }

    public boolean isOrderPlacedSuccessfully() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(successAlert)).getText().contains("placed successfully");
    }
}
