package com.example.countries;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import org.junit.jupiter.api.BeforeEach;
import static io.restassured.RestAssured.config;
import static io.restassured.config.HeaderConfig.headerConfig;

public abstract class BaseTest {

    @BeforeEach
    void setup()
    {
        String apiKey = System.getenv("RC_API_KEY");
        if(apiKey == null || apiKey.isBlank())
        {
            throw new IllegalStateException("Set the RC_API_KEY environment variable");
        }
        RestAssured.baseURI="https://api.restcountries.com";
        RestAssured.config = config().headerConfig(headerConfig().overwriteHeadersWithName("Authorization"));
        RestAssured.requestSpecification = new RequestSpecBuilder()
                .addHeader("Authorization","Bearer "+apiKey.trim()).build();
    }
}
