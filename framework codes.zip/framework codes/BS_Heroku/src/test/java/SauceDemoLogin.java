import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class SauceDemoLogin {

    WebDriver driver;
    WebDriverWait wait;

    public static final String USERNAME = System.getenv("bs_username");
    public static final String ACCESS_KEY = System.getenv("bs_token");
    public static final String BROWSERSTACK_URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";

    public void markTestStatus(String status, String reason, WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("browserstack_executor: " +
                "{\"action\": \"setSessionStatus\",\"arguments\":{\"status\":\"" + status +
                "\",\"reason\": \"" + reason + "\"}}");
    }


    @Parameters({"os","osVersion","browserName","browserVersion","deviceName","realMobile"})
    @BeforeMethod
    public void setup(@Optional("") String os, @Optional("") String osVersion,
                      @Optional("") String browserName, @Optional("") String browserVersion,
                      @Optional("") String deviceName, @Optional("") String realMobile)
            throws InterruptedException, MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        HashMap<String, Object> bstackOptions = new HashMap<>();

        bstackOptions.put("os",os);
        bstackOptions.put("osVersion",osVersion);

        bstackOptions.put("projectName", "CCST BrowserStack SauceDemo");
        bstackOptions.put("buildName", "TestNG Build 1.1");
        bstackOptions.put("sessionName","CCST BrowserStack SauceDemo");
        bstackOptions.put("deviceName",deviceName);
        bstackOptions.put("realMobile",realMobile);

        capabilities.setCapability("bstack:options",bstackOptions);
        capabilities.setCapability("browserName",browserName);
        capabilities.setCapability("browserVersion",browserVersion);

        driver = new RemoteWebDriver(new URL(BROWSERSTACK_URL),capabilities);
        wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        //driver.manage().window().maximize();
        Thread.sleep(1000);
    }

    @Test
    public void loginWithValidCredentials() {
        try {
            driver.get("https://www.saucedemo.com/");

            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
            WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-button")));

            username.sendKeys("standard_user");
            password.sendKeys("secret_sauce");
            loginButton.click();

            WebElement inventoryList = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("inventory_list")));
            Assert.assertTrue(inventoryList.isDisplayed(), "Inventory page should be displayed after successful login.");

            markTestStatus("Passed", "SauceDemo valid login validation successful.", driver);
        } catch (Exception e) {
            markTestStatus("Failed", "SauceDemo valid login validation failed: " + e.getMessage(), driver);
            Assert.fail("SauceDemo valid login validation failed: " + e.getMessage());
        }
    }

    @Test
    public void loginWithInvalidCredentials() {
        try {
            driver.get("https://www.saucedemo.com/");

            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
            WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("login-button")));

            username.sendKeys("standard_user");
            password.sendKeys("wrong_password");
            loginButton.click();

            WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
            Assert.assertTrue(errorMessage.getText().contains("Username and password do not match any user in this service"),
                    "Expected invalid login error message should be displayed.");

            markTestStatus("Passed", "SauceDemo invalid login validation successful.", driver);
        } catch (Exception e) {
            markTestStatus("Failed", "SauceDemo invalid login validation failed: " + e.getMessage(), driver);
            Assert.fail("SauceDemo invalid login validation failed: " + e.getMessage());
        }
    }

    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

